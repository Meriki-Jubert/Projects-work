// server.js - Backend for Student Registration System

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = 3000;

// Middleware setup
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploads and public files statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Serve main HTML page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Ensure uploads folder exists
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1e9) + path.extname(file.originalname);
    cb(null, uniqueName);
  },
});
const upload = multer({ storage });

// SQLite database setup
const db = new sqlite3.Database('Registration.db', (err) => {
  if (err) {
    console.error('Failed to connect to database:', err.message);
    process.exit(1);
  }
  console.log('Connected to SQLite DB');

  db.run(
    `CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      firstName TEXT NOT NULL,
      lastName TEXT NOT NULL,
      dob TEXT NOT NULL,
      gender TEXT NOT NULL,
      classLevel TEXT NOT NULL,
      department TEXT,
      series TEXT,
      feesPaid INTEGER NOT NULL,
      profilePic TEXT
    )`,
    (err) => {
      if (err) console.error('Error creating students table:', err.message);
    }
  );
});

// Helper: Delete old profile picture file safely
function deleteFileIfExists(filePath) {
  if (filePath && filePath.startsWith('/uploads/')) {
    const fullPath = path.join(__dirname, filePath);
    fs.unlink(fullPath, (err) => {
      if (err && err.code !== 'ENOENT') {
        console.error('Error deleting file:', err);
      }
    });
  }
}

// Routes

// GET all students
app.get('/api/students', (req, res) => {
  db.all('SELECT * FROM students ORDER BY id DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// POST new student
app.post('/api/students', upload.single('profilePic'), (req, res) => {
  const {
    firstName,
    lastName,
    dob,
    gender,
    classLevel,
    department = null,
    series = null,
    feesPaid,
  } = req.body;

  const profilePic = req.file ? `/uploads/${req.file.filename}` : null;

  if (!firstName || !lastName || !dob || !gender || !classLevel || feesPaid === undefined) {
    return res.status(400).json({ error: 'Missing required student fields' });
  }

  db.run(
    `INSERT INTO students (firstName, lastName, dob, gender, classLevel, department, series, feesPaid, profilePic)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [firstName, lastName, dob, gender, classLevel, department, series, feesPaid, profilePic],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.status(201).json({ id: this.lastID });
    }
  );
});

// PUT update existing student
app.put('/api/students/:id', upload.single('profilePic'), (req, res) => {
  const id = req.params.id;
  const {
    firstName,
    lastName,
    dob,
    gender,
    classLevel,
    department = null,
    series = null,
    feesPaid,
    existingPic = null,
  } = req.body;

  if (!firstName || !lastName || !dob || !gender || !classLevel || feesPaid === undefined) {
    return res.status(400).json({ error: 'Missing required student fields' });
  }

  const newProfilePic = req.file ? `/uploads/${req.file.filename}` : existingPic;

  // Fetch existing profile pic to delete if replaced
  db.get('SELECT profilePic FROM students WHERE id = ?', [id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.status(404).json({ error: 'Student not found' });

    if (req.file && row.profilePic && row.profilePic !== newProfilePic) {
      deleteFileIfExists(row.profilePic);
    }

    db.run(
      `UPDATE students SET
        firstName = ?, lastName = ?, dob = ?, gender = ?, classLevel = ?,
        department = ?, series = ?, feesPaid = ?, profilePic = ?
      WHERE id = ?`,
      [firstName, lastName, dob, gender, classLevel, department, series, feesPaid, newProfilePic, id],
      function (updateErr) {
        if (updateErr) return res.status(500).json({ error: updateErr.message });
        if (this.changes === 0) return res.status(404).json({ error: 'Student not found' });
        res.json({ updated: this.changes });
      }
    );
  });
});

// DELETE student
app.delete('/api/students/:id', (req, res) => {
  const id = req.params.id;

  // Get profilePic path before deletion to remove file
  db.get('SELECT profilePic FROM students WHERE id = ?', [id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.status(404).json({ error: 'Student not found' });

    db.run('DELETE FROM students WHERE id = ?', [id], function (delErr) {
      if (delErr) return res.status(500).json({ error: delErr.message });

      // Delete profile picture if exists
      if (row.profilePic) {
        deleteFileIfExists(row.profilePic);
      }

      if (this.changes === 0) return res.status(404).json({ error: 'Student not found' });
      res.json({ deleted: this.changes });
    });
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});