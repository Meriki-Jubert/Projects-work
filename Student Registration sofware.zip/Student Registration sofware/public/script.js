
// Fees mapped by classLevel key
const classFees = {
  form1: 60000,
  form2: 60000,
  form3: 70000,
  form4: 70000,
  form5: 80000,
  lowersixth: 70000,
  uppersixth: 80000,
};

//My Utility Functions

// Function to update the stats container numbers
function updateStats(students) {
    const totalStudents = students.length;

    const completedFees = students.filter(student => {
        const requiredFees = classFees[student.classLevel] || 0;
        return student.feesPaid >= requiredFees;
    }).length;

    const owingFees = totalStudents - completedFees;

    // Update DOM
    document.getElementById('total-students').textContent = totalStudents;
    document.getElementById('completed-fees').textContent = completedFees;
    document.getElementById('owing-fees').textContent = owingFees;
}

// Format number as currency (FRS)
function formatCurrency(amount) {
  return amount.toLocaleString('en-US', { style: 'currency', currency: 'XAF', minimumFractionDigits: 0 });
}

// Format date as readable string
function formatDate(dateStr) {
  const d = new Date(dateStr);
  if (isNaN(d)) return '';
  return d.toLocaleDateString();
}

// Calculate age from date of birth string
function calculateAge(dobStr) {
  const birthDate = new Date(dobStr);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}

// Display-friendly names for classes
function getClassDisplayName(classKey) {
  const map = {
    form1: 'Form 1',
    form2: 'Form 2',
    form3: 'Form 3',
    form4: 'Form 4',
    form5: 'Form 5',
    lowersixth: 'Lower Sixth',
    uppersixth: 'Upper Sixth',
  };
  return map[classKey] || classKey;
}

// Display-friendly department names
function getDepartmentDisplayName(deptKey) {
  const map = {
    arts: 'Arts',
    science: 'Science',
  };
  return map[deptKey] || deptKey;
}

// Display-friendly series names
function getSeriesDisplayName(seriesKey) {
  const map = {
    A1: 'A1 - Literature & Languages',
    A2: 'A2 - History & Geography',
    A3: 'A3 - Economics & Sociology',
    A4: 'A4 - Arts & Philosophy',
    S1: 'S1 - Mathematics & Physics',
    S2: 'S2 - Biology & Geology',
    S3: 'S3 - Technology & Engineering',
    S4: 'S4 - Computer Science',
  };
  return map[seriesKey] || seriesKey;
}

// DOM References

const studentForm = document.getElementById('student-form');
const studentContainer = document.getElementById('studentContainer');
const notification = document.getElementById('notification');

const searchInput = document.getElementById('search-input');
const searchClass = document.getElementById('search-class');
const searchGender = document.getElementById('search-gender');
const searchAge = document.getElementById('search-age');

const searchBtn = document.getElementById('search-btn');
const resetSearchBtn = document.getElementById('reset-search-btn');
const printAllBtn = document.getElementById('print-all-btn');

const departmentSection = document.getElementById('department-section');
const seriesSection = document.getElementById('series-section');

const departmentSelect = document.getElementById('department');
const seriesSelect = document.getElementById('series');

const classSelect = document.getElementById('class');

// State
let students = [];
let filteredStudents = [];

// Fetch All Students from Backend

async function fetchStudents() {
  try {
    const response = await fetch('/api/students');
    if (!response.ok) throw new Error('Failed to fetch students');
    students = await response.json();
    filteredStudents = [...students];
    renderStudents(filteredStudents);
    updateStats(students); // Update stats after fetching
  } catch (error) {
    showNotification('Error loading students: ' + error.message, 'error');
  }
}

// Render Student Cards List

function renderStudents(studentList) {
  if (studentList.length === 0) {
    studentContainer.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-user-graduate fa-3x" style="color: #ccc; margin-bottom: 20px;"></i>
        <h3>No Students Found</h3>
        <p>Try adding some students or adjusting your search</p>
      </div>`;
    return;
  }

  // Generate HTML cards for each student
  studentContainer.innerHTML = studentList.map(renderStudentCard).join('');

  // Attach event listeners to the dynamic buttons inside student cards
  attachCardEventListeners();
}

// Render a Single Student Card with FULL details including fees, dept, series, pic

function renderStudentCard(student) {
  const classValue = student.classLevel;
  const requiredFees = classFees[classValue] || 0;
  const balance = requiredFees - student.feesPaid;
  const feesStatus = balance > 0
    ? `<div class="fees-status status-owing">Still Owing: ${formatCurrency(balance)}</div>`
    : `<div class="fees-status status-completed">Completed</div>`;

  const age = calculateAge(student.dob);

  return `
    <div class="student-card" data-id="${student.id}">
      <div class="student-header">
        <div class="student-avatar">
          ${student.profilePic ? `<img src="${student.profilePic}" alt="${student.firstName}">` : `<i class="fas fa-user"></i>`}
        </div>
        <div class="student-name">${student.firstName} ${student.lastName}</div>
      </div>
      <div class="student-details">
        <p><strong>ID:</strong> ${student.id}</p>
        <p><strong>Gender:</strong> ${student.gender}</p>
        <p><strong>Date of Birth:</strong> ${formatDate(student.dob)} (${age} years old)</p>
        <p><strong>Class:</strong> ${getClassDisplayName(classValue)}</p>
        ${student.department ? `<p><strong>Department:</strong> ${getDepartmentDisplayName(student.department)}</p>` : ''}
        ${student.series ? `<p><strong>Series:</strong> ${getSeriesDisplayName(student.series)}</p>` : ''}
        <p><strong>Required Fees:</strong> ${formatCurrency(requiredFees)}</p>
        <p><strong>Fees Paid:</strong> ${formatCurrency(student.feesPaid)}</p>
        ${feesStatus}
      </div>
      <div class="student-actions">
        <button class="btn btn-secondary edit-btn"><i class="fas fa-edit"></i> Edit</button>
        <button class="btn btn-danger delete-btn"><i class="fas fa-trash"></i> Delete</button>
        <button class="btn btn-success print-btn"><i class="fas fa-print"></i> Print</button>
      </div>
    </div>
  `;
}

// Attach event listeners to student card buttons (Edit, Delete, Print)

function attachCardEventListeners() {
  // Edit buttons
  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', onEditStudent);
  });

  // Delete buttons
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', onDeleteStudent);
  });

  // Print buttons (print single student card)
  document.querySelectorAll('.print-btn').forEach(btn => {
    btn.addEventListener('click', onPrintSingleStudent);
  });
}

// Print Single Student Card (original design)

function onPrintSingleStudent(e) {
  const card = e.target.closest('.student-card');
  if (!card) return;
  const studentId = card.dataset.id;
  const student = students.find(s => s.id == studentId);
  if (!student) return;
  printStudent(student);
}

// Print student in original card style with picture and fees info
function printStudent(student) {
  const printWindow = window.open('', '_blank');
  const classValue = student.classLevel;
  const requiredFees = classFees[classValue] || 0;
  const balance = requiredFees - student.feesPaid;
  const feesStatus = balance > 0
    ? `<div class="fees-status status-owing">Still Owing: ${formatCurrency(balance)}</div>`
    : `<div class="fees-status status-completed">Completed</div>`;

  const age = calculateAge(student.dob);

  const content = `
  <html>
  <head>
    <title>LORDS BILLINGUAL ACADEMY KUMBA</title>
    <style>
      body { 
      font-family: Arial, sans-serif; 
      margin: 20px; 
      }
      .student-card { 
      border: 1px solid #ccc; 
      padding: 15px; 
      border-radius: 5px; 
      max-width: 400px; 
      }
      .student-avatar img { 
      width: 80px; 
      height: 80px; 
      border-radius: 50%; 
      margin-bottom: 10px; 
      }
      .fees-status { 
      font-weight: bold; 
      margin-top: 10px; 
      padding: 5px; 
      border-radius: 3px; 
      display: inline-block; 
      }
      .status-owing { 
      background-color:rgb(244, 149, 7); 
      color:rgb(0, 0, 0); }
      .status-completed { 
      background-color: #d4edda; 
      color: #155724; }
    </style>
  </head>
  <body>
    <h1>LORDS BILLINGUAL ACADEMY</h1>
    <h2>Student Information</h2>
    <div class="student-card">
      <div class="student-avatar">
        ${student.profilePic ? `<img src="${student.profilePic}" alt="${student.firstName}">` : `<i class="fas fa-user" style="font-size: 80px;"></i>`}
      </div>
      <p><strong>ID:</strong> ${student.id}</p>
      <p><strong>Name:</strong> ${student.firstName} ${student.lastName}</p>
      <p><strong>Gender:</strong> ${student.gender}</p>
      <p><strong>Date of Birth:</strong> ${formatDate(student.dob)} (${age} years old)</p>
      <p><strong>Class:</strong> ${getClassDisplayName(classValue)}</p>
      ${student.department ? `<p><strong>Department:</strong> ${getDepartmentDisplayName(student.department)}</p>` : ''}
      ${student.series ? `<p><strong>Series:</strong> ${getSeriesDisplayName(student.series)}</p>` : ''}
      <p><strong>Required Fees:</strong> ${formatCurrency(requiredFees)}</p>
      <p><strong>Fees Paid:</strong> ${formatCurrency(student.feesPaid)}</p>
      ${feesStatus}
    </div>
  </body>
  </html>`;

  printWindow.document.write(content);
  printWindow.document.close();
  printWindow.print();
}

// Handle Student Form Submission (Add or Update)

studentForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  // Get form data
  const formData = new FormData(studentForm);
  const id = studentForm.dataset.editingId;

  try {
    let response;
    if (id) {
      // Update existing student
      response = await fetch(`/api/students/${id}`, {
        method: 'PUT',
        body: formData,
      });
    } else {
      // Add new student
      response = await fetch('/api/students', {
        method: 'POST',
        body: formData,
      });
      updateStats(students);
    }

    if (!response.ok) throw new Error('Server error');

    const result = await response.json();

    // Refresh student list after operation
    await fetchStudents();
    resetForm();

    showNotification(id ? 'Student updated successfully' : 'Student added successfully', 'success');
    studentForm.reset();
    updateStats();
  } catch (error) {
    showNotification('Error saving student: ' + error.message, 'error');
  }
});

// Reset Form to blank state

function resetForm() {
  studentForm.reset();
  delete studentForm.dataset.editingId;
  // Hide conditional sections on reset
  departmentSection.style.display = 'none';
  seriesSection.style.display = 'none';
}

// Edit Student - populate form with existing data

function onEditStudent(e) {
  const card = e.target.closest('.student-card');
  if (!card) return;
  const studentId = card.dataset.id;
  const student = students.find(s => s.id == studentId);
  if (!student) return;

  // Populate form fields
  studentForm.dataset.editingId = studentId;
  studentForm.firstName.value = student.firstName;
  studentForm.lastName.value = student.lastName;
  studentForm.dob.value = student.dob;
  studentForm.gender.value = student.gender;
  studentForm.classLevel.value = student.classLevel;
  studentForm.feesPaid.value = student.feesPaid;

  // Show or hide Department & Series based on class
  handleConditionalSections(student.classLevel);

  if (student.department) studentForm.department.value = student.department;
  else studentForm.department.value = '';

  if (student.series) studentForm.series.value = student.series;
  else studentForm.series.value = '';
}

// Delete Student with confirmation

async function onDeleteStudent(e) {
  const card = e.target.closest('.student-card');
  if (!card) return;
  const studentId = card.dataset.id;

  if (!confirm('Are you sure you want to delete this student?')) return;

  try {
    const response = await fetch(`/api/students/${studentId}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error('Failed to delete student');

    await fetchStudents();
    updateStats(students);
    showNotification('Student deleted successfully', 'success');
  } catch (error) {
    showNotification('Error deleting student: ' + error.message, 'error');
  }
}

// Show notifications to user

function showNotification(message, type = 'info') {
  notification.textContent = message;
  notification.className = `notification ${type}`;
  notification.style.display = 'block';

  setTimeout(() => {
    notification.style.display = 'none';
  }, 3000);
}

// Handle Class Select change to show/hide Department and Series fields

classSelect.addEventListener('change', (e) => {
  const selectedClass = e.target.value;
  handleConditionalSections(selectedClass);
});

function handleConditionalSections(selectedClass) {
  // Department appears only for Lower Sixth and Upper Sixth
  if (selectedClass === 'lowersixth' || selectedClass === 'uppersixth' || selectedClass === 'form3' || selectedClass === 'form4' || selectedClass === 'form5') {
    departmentSection.style.display = 'block';
  } else {
    departmentSection.style.display = 'none';
    departmentSelect.value = '';
  }

  // Series visible only for lowersixth and uppersixth as well
  if (selectedClass === 'lowersixth' || selectedClass === 'uppersixth') {
    seriesSection.style.display = 'block';
  } else {
    seriesSection.style.display = 'none';
    seriesSelect.value = '';
  }
}

// Search Logic - filter students based on search criteria

searchBtn.addEventListener('click', () => {
  const nameTerm = searchInput.value.trim().toLowerCase();
  const classTerm = searchClass.value;
  const genderTerm = searchGender.value;
  const ageTerm = searchAge.value ? parseInt(searchAge.value) : null;

  filteredStudents = students.filter(student => {
    const fullName = (student.firstName + ' ' + student.lastName).toLowerCase();
    const studentAge = calculateAge(student.dob);

    // Match name
    const nameMatches = fullName.includes(nameTerm);

    // Match class if selected
    const classMatches = classTerm ? (student.classLevel === classTerm) : true;

    // Match gender if selected
    const genderMatches = genderTerm ? (student.gender === genderTerm) : true;

    // Match age if entered
    const ageMatches = ageTerm !== null ? (studentAge === ageTerm) : true;

    return nameMatches && classMatches && genderMatches && ageMatches;
  });
  renderStudents(filteredStudents);
  updateStats(filteredStudents);
});

// Reset Search Filters and Show All Students

resetSearchBtn.addEventListener('click', () => {
  searchInput.value = '';
  searchClass.value = '';
  searchGender.value = '';
  searchAge.value = '';
  filteredStudents = [...students];
  renderStudents(filteredStudents);
  updateStats(filteredStudents);
});

// Print All Students (table layout, includes First/Last Name, Class, Dept, Fees owed)

printAllBtn.addEventListener('click', () => {
  if (filteredStudents.length === 0) {
    alert('No students to print.');
    return;
  }
  printStudentsTable(filteredStudents);
});

function printStudentsTable(studentsToPrint) { 
    const printWindow = window.open('', '_blank'); 
    const rowsHtml = studentsToPrint.map(student => { 
        const requiredFees = classFees[student.classLevel] || 0; 
        const balance = requiredFees - student.feesPaid; 
        const feesOwing = balance > 0 ? formatCurrency(balance) : 'None'; 
        return `
        <tr> 
        <td>${student.id}</td> 
        <td>${student.firstName}</td>
        <td>${student.lastName}</td> 
        <td>${student.gender}</td> 
        <td>${formatDate(student.dob)}</td> 
        <td>${getDepartmentDisplayName(student.department || '')}</td> 
        <td>${getClassDisplayName(student.classLevel)}</td> 
        <td>${feesOwing}</td> 
        </tr>`; 
    }).join('');

const content = `

  <html>
  <head>
    <title>Print Students Table</title>
    <style>
      body { font-family: Arial, sans-serif; margin: 20px; }
      table { border-collapse: collapse; width: 100%; }
      th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
      th { background-color: #f2f2f2; }
      h1 { text-align: center; margin-bottom: 20px; }
    </style>
  </head>
  <body>
    <h1>Students Report</h1>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Gender</th>
          <th>Date of Birth</th>
          <th>Department</th>
          <th>Class</th>
          <th>Fees Owing</th>
        </tr>
      </thead>
      <tbody>
        ${rowsHtml}
      </tbody>
    </table>
  </body>
  </html>`;
  printWindow.document.write(content); 
  printWindow.document.close(); 
  printWindow.print(); 
}

// Initialize on page load
fetchStudents();